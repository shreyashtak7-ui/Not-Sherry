wimport tkinter as tk
from tkinter import messagebox

# Hardcoded credentials
CORRECT_USERNAME = "admin"
CORRECT_PASSWORD = "password123"

def login():
    username = entry_username.get()
    password = entry_password.get()

    if username == CORRECT_USERNAME and password == CORRECT_PASSWORD:
        messagebox.showinfo("Login Success", "Welcome to the system!")
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")

# Create main window
root = tk.Tk()
root.title("Login System")
root.geometry("350x200")
root.resizable(False, False)

# Username Label & Entry
tk.Label(root, text="Username:", font=("Arial", 12)).pack(pady=5)
entry_username = tk.Entry(root, font=("Arial", 12))
entry_username.pack(pady=5)

# Password Label & Entry
tk.Label(root, text="Password:", font=("Arial", 12)).pack(pady=5)
entry_password = tk.Entry(root, show="*", font=("Arial", 12))
entry_password.pack(pady=5)

# Login Button
tk.Button(root, text="Login", command=login, font=("Arial", 12), bg="lightblue").pack(pady=15)

# Run application
root.mainloop()
