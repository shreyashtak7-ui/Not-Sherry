# fancy_goodnight.py

def good_night(name):
    print("★彡[Good Night]彡★")
    print(f"   Sweet Dreams, {name}! 🌙✨")
    print("★彡[Sleep Well]彡★")

good_night("Mayu")
python good_night.pypython good_night.py
 # output:
 
